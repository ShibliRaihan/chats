import "./App.css";
import Chat from "./Components/Chat";

function App() {
  return <><Chat/></>;
}

export default App;
