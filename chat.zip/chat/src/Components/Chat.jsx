import { Stack } from "@mui/system";
import React from "react";
import ChatsText from "./ChatsBox/ChatsText";
import MemberBox from "./ChatsBox/MemberBox";
import MemberInfo from "./ChatsBox/MemberInfo";

const Chat = () => {
  return (
    <>
    <Stack direction="row">
      <MemberBox />
      <ChatsText />
      <MemberInfo/>
    </Stack>
    </>
  );
};

export default Chat;
