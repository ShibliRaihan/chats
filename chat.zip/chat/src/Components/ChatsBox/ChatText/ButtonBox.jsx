import React from "react";
import "./style/style.css";
import KeyboardVoiceOutlinedIcon from "@mui/icons-material/KeyboardVoiceOutlined";
import AttachFileOutlinedIcon from "@mui/icons-material/AttachFileOutlined";
import CameraAltOutlinedIcon from "@mui/icons-material/CameraAltOutlined";
import EmojiEmotionsOutlinedIcon from "@mui/icons-material/EmojiEmotionsOutlined";
import SendOutlinedIcon from "@mui/icons-material/SendOutlined";
import { Stack } from "@mui/system";
import { Box, Button } from "@mui/material";

export const ButtonBox = () => {
  return (
    <>
      <Box sx={{ my: "20px",  }}>
        <Stack direction={"row"}>
          <KeyboardVoiceOutlinedIcon
            sx={{
              fontSize: "32px",
              mt: "",
              padding: "10px",
              backgroundColor: "#f9f9f9",
              borderRadius: "25px 0px 0px 25px",
              color: "#d9d9d9",
              cursor: "pointer",
            }}
          />
          <input className="msg" placeholder="Writing Something" />
          <AttachFileOutlinedIcon
            sx={{
              fontSize: "32px",
              mt: "",
              padding: "10px",
              backgroundColor: "#f9f9f9",
              color: "#d9d9d9",
              cursor: "pointer",
            }}
          />
          <CameraAltOutlinedIcon
            sx={{
              fontSize: "32px",
              mt: "",
              padding: "10px",
              backgroundColor: "#f9f9f9",
              color: "#d9d9d9",
              cursor: "pointer",
            }}
          />
          <EmojiEmotionsOutlinedIcon
            sx={{
              fontSize: "32px",
              mt: "",
              padding: "10px",
              backgroundColor: "#f9f9f9",
              // borderRadius: "0px 25px 25px 1px",
              color: "#d9d9d9",
              cursor: "pointer",
              paddingRight: "20px",
            }}
          />
          <Button
            variant="contained"
            sx={{ borderRadius: "25px" }}
            endIcon={<SendOutlinedIcon />}
          ></Button>
        </Stack>
      </Box>
    </>
  );
};
