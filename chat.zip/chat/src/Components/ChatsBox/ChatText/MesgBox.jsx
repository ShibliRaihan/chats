import { Divider, Typography } from "@mui/material";
import { Box } from "@mui/system";
import React from "react";
import Oposite from "./Oposite";
import Send from "./Send";

const MesgBox = () => {
  return (
    <>
      <Box
        className="scrollbar"
        sx={{ maxHeight: "650px", overflow: "scroll", overflowX: "hidden" }}
      >
        <Divider sx={{ my: "10px" }}>
          <Typography>Tomorro</Typography>
        </Divider>
        <Box sx={{}}>
          <Oposite text="That's gread Hello! I am shibli.  gertjl s dfnkj hsen" />
          <Oposite text="That's gread" />
          <Oposite text="That's gread" />
          <Oposite text="That's gread" />
          <Oposite text="That's gread" />
          <Oposite text="That's gread" />
        </Box>
        <Divider sx={{ my: "10px" }}>
          <Typography>Today</Typography>
        </Divider>
        <Box sx={{}}>
          <Send text="Hello! Hello! I am shibli.  gertjl s dfnkj hsen " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
          <Send text="Hello! " />
        </Box>
      </Box>
    </>
  );
};

export default MesgBox;
// height: "75%"
