import React from "react";
import { Avatar, Stack, Typography } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const Oposite = (props) => {
  return (
    <>
    <Stack direction={"row"} sx={{ my: "30px" }}>
      <Avatar alt="Remy Sharp" src={require("./img/1st.png")} />
      <Typography sx={{mt:"10px", ml:"10px"}}>Name Name</Typography>
    </Stack>
      <Stack direction={"row"} sx={{ my: "30px" }}>
        <Typography
          sx={{
            mt: "10px",
            backgroundColor: "#BDC1C0",
            color: "#FFFF",
            padding: "3px 20px",
            mx: "10px",
            borderRadius: "15px",
          }}
        >
          {props.text}
          <Stack
            direction={"row"}
            sx={{ justifyContent: "flex-end", my: "10px" }}
          >
            <Typography>9 AM</Typography>
            <MoreVertIcon />
          </Stack>
        </Typography>
      </Stack>
    </>
  );
};

export default Oposite;
