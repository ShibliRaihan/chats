import React from "react";
import { Stack, Typography } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const Send = (props) => {
  return (
    <>
      <Stack direction={"row"} sx={{ my: "30px", justifyContent: "flex-end",}}>
        <Typography
          sx={{
            mt: "10px",
            backgroundColor: "#727aff",
            color: "#FFFF",
            padding: "3px 20px",
            mx: "10px",
            borderRadius: "15px",
          }}
        >
          {props.text}
          <Stack direction={"row"} sx={{ justifyContent: "flex-end", my:"10px" }}>
            <Typography>9 AM</Typography>
            <MoreVertIcon />
          </Stack>
        </Typography>
      </Stack>
    </>
  );
};

export default Send;
