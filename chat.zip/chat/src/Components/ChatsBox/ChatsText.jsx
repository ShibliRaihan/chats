import React from "react";
import Box from "@mui/material/Box";
import TopBar from "./ChatText/TopBar";
import { ButtonBox } from "./ChatText/ButtonBox";
import MesgBox from "./ChatText/MesgBox";
import { Divider } from "@mui/material";

const ChatsText = () => {
  return (
    <>
      <Box
        className="scrollbar"
        sx={{
          width: 2 / 4,
          backgroundColor: "#FFFF",
          height: "100vh",
          overflow: "auto",
          padding: "25px 25px 0px 25px",
        }}
      >
        <TopBar/>
        <MesgBox />
        <Divider sx={{ my: "10px" }} />
        <ButtonBox />
      </Box>
    </>
  );
};

export default ChatsText;
