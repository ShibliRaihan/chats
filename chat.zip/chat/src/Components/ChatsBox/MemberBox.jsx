import React from "react";
import Box from "@mui/material/Box";
import { Stack } from "@mui/system";
import AccountHead from "./MemberBox/AccountHead";
import SearchBar from "./MemberBox/SearchBar";
import "./Style/index.css";
import Member from "./MemberBox/Member";

const MemberBox = () => {
  return (
    <Box
      className="scroll"
      sx={{
        width: 1 / 4,
        backgroundColor: "#F9F9F9",
        height: "100vh",
        overflow: "scroll",
        overflowX: "hidden",
      }}
    >
      <Stack direction={"column"}>
        <AccountHead />
        <SearchBar />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
        <Member name="Line Roy" dec="lorem yea kfy dcvasd" time="09:30 AM" />
      </Stack>
    </Box>
  );
};

export default MemberBox;
