import { Stack } from "@mui/system";
import ModeOutlinedIcon from "@mui/icons-material/ModeOutlined";
import React from "react";
import "./style/index.css";
import { IconButton } from "@mui/material";
const AccountHead = () => {
  return (
    <>
      <Stack direction={"row"} sx={{ my: "20px" }}>
        <img className="men" src={require("./img/1st.png")} alt="img" />
        <Stack direction={"column"} width="250px" sx={{ ml: "25px" }}>
          <h4 className="m-0 names">Gravide Crlstofer</h4>
          <p className="m-0">Senioure</p>
        </Stack>
        <IconButton sx={{ height: "50px" }}>
          <ModeOutlinedIcon sx={{ fontSize: "32px" }} />
        </IconButton>
      </Stack>
    </>
  );
};

export default AccountHead;
