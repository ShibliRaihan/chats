import { Box, Stack } from "@mui/system";
import Avatar from "@mui/material/Avatar";
import React from "react";
import { Divider } from "@mui/material";

const Member = (props) => {
  return (
    <>
      <Box sx={{ width: "80%", mx: "auto" }}>
        <Stack direction={"row"}>
          <Avatar alt="Remy Sharp" src={require("./img/1st.png")} />
          <Stack
            direction={"column"}
            sx={{ margin: " 0px 10px", cursor: "pointer" }}
          >
            <h5 className="m-0">{props.name}</h5>
            <p className="m-0">{props.dec}</p>
          </Stack>
          <Stack direction={"column"} sx={{ marginLeft: "32px" }}>
            <p>{props.time}</p>
          </Stack>
        </Stack>
      <Divider sx={{my:"10px"}} ></Divider>
      </Box>
    </>
  );
};

export default Member;
