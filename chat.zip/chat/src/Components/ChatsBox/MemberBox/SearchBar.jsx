import React from "react";
import Box from "@mui/material/Box";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
const SearchBar = () => {
  return (
    <>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        sx={{
          maxWidth: "100%",
          borderRadius: "25px",
          my:"20px"
        }}
      >
        <SearchOutlinedIcon
          sx={{
            backgroundColor: "#ffff",
            fontSize: "30px",
            padding: "7px",
            borderRadius: " 25px 0px 0px 25px",
            cursor:"pointer"
          }}
        />
        <input className="search" placeholder="Search People" />
      </Box>
    </>
  );
};

export default SearchBar;
