import React from "react";
import Box from "@mui/material/Box";
import SearchBar from "./MemberBox/SearchBar";
import MemberProfile from "./MemberInfoBox/MemberProfile";
import CallBox from "./MemberInfoBox/CallBox";
import FunctionBox from "./MemberInfoBox/FunctionBox";
import Auttochments from "./MemberInfoBox/Auttochments";
const MemberInfo = () => {
  return (
    <>
      <Box
        sx={{
          width: 1 / 4,
          backgroundColor: "#F9F9F9",
          // height: "100vh",
          // overflow: "auto",
          overflow: "hidden",
        }}
      >
        <SearchBar />
        <MemberProfile/>
        <CallBox/>
        <FunctionBox/>
        <Auttochments/>
      </Box>
    </>
  );
};

export default MemberInfo;
