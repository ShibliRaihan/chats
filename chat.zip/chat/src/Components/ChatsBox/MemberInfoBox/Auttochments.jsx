import { Stack, Typography, Container, Button } from "@mui/material";
import { width } from "@mui/system";
import React from "react";
import AuttochmentsBox from "./AuttochmentsBox";

const Auttochments = () => {
  return (
    <>
      <Typography variant="h6" sx={{ ml: "30px", my: "25px" }}>
        Auttochments
      </Typography>
      <Container>
        <Stack direction={"row"} spacing={2}>
          <AuttochmentsBox text="PCF" />
          <AuttochmentsBox text="Video" />
          <AuttochmentsBox text="Mp3" />
          <AuttochmentsBox text="Img" />
        </Stack>
      </Container>
      <Button variant="outlined" sx={{borderRadius:"25px", height:"35px", mt:"20px", mx:"auto", display:"block"}}>View All</Button>
    </>
  );
};

export default Auttochments;
