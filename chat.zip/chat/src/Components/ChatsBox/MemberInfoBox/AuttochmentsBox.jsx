import { Box } from "@mui/system";
import React from "react";

const AuttochmentsBox = (props) => {
  return (
    <>
      <Box
        sx={{
          backgroundColor: "#eaecfe",
          width: 1 / 5,
          height: "70px",
          mx: "10",
          borderRadius: "10px",
          color: "#c1cff5",
          textAlign: "center",
        }}
      >
        <span className="Auttochments">{props.text}</span>
      </Box>
    </>
  );
};

export default AuttochmentsBox;
