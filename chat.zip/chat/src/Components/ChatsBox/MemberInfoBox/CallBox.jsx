import React from "react";
import ChatBubbleIcon from "@mui/icons-material/ChatBubble";
import VideocamIcon from "@mui/icons-material/Videocam";
import { Box, Stack } from "@mui/system";
import Divider from "@mui/material/Divider";
import { Typography } from "@mui/material";
const CallBox = () => {
  return (
    <>
      <Stack
        direction={"row"}
        divider={<Divider orientation="vertical" flexItem />}
        sx={{
          marginTop: "60px",
        }}
      >
        <Box>
          <ChatBubbleIcon
            sx={{
              fontSize: "35px",
              padding: "7px",
              backgroundColor: "#eaedff",
              borderRadius: "50%",
              color: "#4c7cff",
              cursor: "pointer",
              mx: "80px",
            }}
          />
          <Typography sx={{mt:"3px", textAlign: "center" }}>Chat</Typography>
        </Box>
        <Box>
          <VideocamIcon
            sx={{
              fontSize: "45px",
              padding: "2px",
              backgroundColor: "#eaedff",
              borderRadius: "50%",
              color: "#4c7cff",
              mx: "80px",
              cursor: "pointer",
            }}
          />
          <Typography sx={{mt:"3px", textAlign: "center" }}>Video Call</Typography>
        </Box>
      </Stack>
    </>
  );
};

export default CallBox;
