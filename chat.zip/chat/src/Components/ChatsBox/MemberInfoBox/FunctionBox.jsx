import { Stack } from "@mui/system";
import React from "react";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
const FunctionBox = () => {
  return (
    <>
      <div className="function">
        <Stack direction={"row"} sx={{my:"10px"}}>
          <AccountCircleOutlinedIcon sx={{fontSize: "30px"}} />
          <span sx={{fontSize:"20px"}}>View Friend</span>
        </Stack>
        <Stack direction={"row"} sx={{my:"10px"}}>
          <FavoriteBorderOutlinedIcon sx={{fontSize: "30px"}} />
          <span sx={{fontSize:"20px"}}>Add To Favorite</span>
        </Stack>
      </div>
    </>
  );
};

export default FunctionBox;
