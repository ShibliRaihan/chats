import React from "react";
import "./Style/index.css";
import Typography from '@mui/material/Typography'
const MemberProfile = () => {
  return (
    <>
      <img
        className="profile"
        alt="Remy Sharp"
        src={require("./img/1st.png")}
      />
      <Typography variant="h5" sx={{textAlign:"center", marginTop:"30px"}}>Dianne Vabnhron</Typography>
      <Typography variant="h6" sx={{textAlign:"center"}}>Dianne Vabnhron</Typography>
    </>
  );
};

export default MemberProfile;
